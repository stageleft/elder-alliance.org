#!/usr/bin/ruby

require 'ritsutter_model.rb'
require 'ritsutter_parser.rb'

open('RiTsutter_Access.txt'){ |file|
  $CONSUMER_KEY    = file.gets.delete(" \t\n\r\f")
  $CONSUMER_SECRET = file.gets.delete(" \t\n\r\f")
  $ACCESS_TOKEN    = file.gets.delete(" \t\n\r\f")
  $ACCESS_SECRET   = file.gets.delete(" \t\n\r\f")
}

ct = RiTsutter::Parser.new()
mo = RiTsutter::Model.new()

puts ct.set_tl(mo.client.home_timeline, true)
puts 
puts ct.set_tl(mo.client.user_timeline, false)
