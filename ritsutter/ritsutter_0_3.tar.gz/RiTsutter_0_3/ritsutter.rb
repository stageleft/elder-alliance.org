#!/usr/bin/ruby -Ku

# constants

# for RiTsutter::Model
$ACCESS_KEY_FILE = 'RiTsutter_Access.txt'
$CONSUMER_KEY    = ''
$CONSUMER_SECRET = ''
$ACCESS_TOKEN    = ''
$ACCESS_SECRET   = ''

# for RiTsutter::View
$APPNAME = 'Ritsutter'
$APPVER  = 'ver 0.1'
$COPYRIGHT = 'Takumi Kanno / Trade-Wind, 2010'
$ABOUT_COMMENT = ''
$LICENSE = '3-clause BSD license'
$WEB_SITE = 'http://www.elder-alliance.org/ritstter/'
$ICON    = 'ritsutter_icon.png'
$WIDTH   = 400
$HEIGHT  = 720
$X_POS   = 0
$Y_POS   = 0

require 'ritsutter_model.rb'
require 'ritsutter_view.rb'
require 'ritsutter_controller.rb'

open($ACCESS_KEY_FILE){ |file|
  $CONSUMER_KEY    = file.gets.delete(" \t\n\r\f")
  $CONSUMER_SECRET = file.gets.delete(" \t\n\r\f")
  $ACCESS_TOKEN    = file.gets.delete(" \t\n\r\f")
  $ACCESS_SECRET   = file.gets.delete(" \t\n\r\f")
}


ritsutter = RiTsutter::Controller.new
