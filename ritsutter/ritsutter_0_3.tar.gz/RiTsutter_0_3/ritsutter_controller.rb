require 'jcode'
require 'ritsutter_model.rb'
require 'ritsutter_parser.rb'
require 'ritsutter_view.rb'

module RiTsutter
  class Controller

    def initialize()
      @view   = RiTsutter::View.new()
      @model  = RiTsutter::Model.new()
      @parser = RiTsutter::Parser.new(@model.my_id)

      @last_message = ""
      @search_word  = ""
      @tweet_option = Hash.new()

      @view.home_tl_button.signal_connect("clicked") { refresh_timeline("home") }
      @view.replytl_button.signal_connect("clicked") { refresh_timeline("mention") }
      @view.self_tl_button.signal_connect("clicked") { refresh_timeline("self") }
      @view.timeline.signal_connect("title")         { |widget| linked_request(widget) }
      @view.tweet_box.signal_connect("key-release-event") { @view.tweet_change(@view.tweet_box.text) }
      @view.tweet_button.signal_connect("clicked")   { tweet_status }

      @view.main_window.show_all
      refresh_timeline("home")

      @view.run
    end

    def refresh_timeline(set_type="")
      if set_type != ""
        @current_timeline_type = set_type
      end
      @view.statusbar_refresh('Loading timeline ' + @current_timeline_type + ' ...')
      begin
        if @current_timeline_type == "mention" then
          @current_timeline = @model.client.mentions()
        elsif @current_timeline_type == "self" then
          @current_timeline = @model.client.user_timeline()
        elsif @current_timeline_type.index("search") == 0 then
          @current_timeline = @model.client.search_timeline(@current_timeline_type.split(":")[1])
        else
          @current_timeline_type = "home"
          @current_timeline = @model.client.home_timeline() # treat as "home"
        end
      rescue Timeout::Error, StandardError=> e
        @view.statusbar_refresh('Error(' + @current_timeline_type + '):' + e.to_s)
        puts 'Error : (' + @current_timeline_type + ')'
        puts e.to_s
        puts e.backtrace
      else
        show_timeline(@current_timeline_type, @current_timeline)
      end
    end

    def add_new_timeline()
      tl_option = Hash.new()
      tl_option.store("since_id", @current_timeline.first.id.to_s)
      @view.statusbar_refresh('Loading new tweet... ')
      begin
        if @current_timeline_type == "mention" then
          new_timeline = @model.client.mentions(tl_option)
        elsif @current_timeline_type == "self" then
          new_timeline = @model.client.user_timeline(tl_option)
        elsif @current_timeline_type.index("search") == 0 then
          new_timeline = @model.client.search_timeline(@current_timeline_type.split(":")[1], @current_timeline.first.id.to_s, true)
        else  # @current_timeline_type as "home"
          new_timeline = @model.client.home_timeline(tl_option)
        end
      rescue Timeout::Error, StandardError=> e
        @view.statusbar_refresh('Error(' + @current_timeline_type + '):' + e.to_s)
        puts 'Error : (' + @current_timeline_type + ')'
        puts e.to_s
        puts e.backtrace
      else
        if new_timeline != nil && new_timeline.size > 0 then
          @current_timeline = new_timeline + @current_timeline
        end
        show_timeline(@current_timeline_type, @current_timeline)
      end
    end

    def add_old_timeline()
      tl_option = Hash.new()
      tl_option.store("max_id", @current_timeline.last.id.to_s)
      @view.statusbar_refresh('Loading past tweet... ')
      begin
        if @current_timeline_type == "mention" then
          old_timeline = @model.client.mentions(tl_option)
        elsif @current_timeline_type == "self" then
          old_timeline = @model.client.user_timeline(tl_option)
        elsif @current_timeline_type.index("search") == 0 then
          old_timeline = @model.client.search_timeline(@current_timeline_type.split(":")[1], @current_timeline.last.id.to_s, false)
        else  # @current_timeline_type as "home"
          old_timeline = @model.client.home_timeline(tl_option)
        end
      rescue Timeout::Error, StandardError=> e
        @view.statusbar_refresh('Error(' + @current_timeline_type + '):' + e.to_s)
        puts 'Error : (' + @current_timeline_type + ')'
        puts e.to_s
        puts e.backtrace
      else
        if old_timeline.size > 1 then
          @current_timeline.pop
          @current_timeline = @current_timeline + old_timeline
        end
        show_timeline(@current_timeline_type, @current_timeline)
      end
    end

    def show_search_timeline(word)
      @current_timeline_type = "search:" + word 
      begin
        @view.statusbar_refresh('Loading search... ')
        @current_timeline = @model.client.search_timeline(word)
      rescue Timeout::Error, StandardError=> e
        @view.statusbar_refresh('Error(' + @current_timeline_type + '):' + e.to_s)
        puts 'Error : (' + @current_timeline_type + ')'
        puts e.to_s
        puts e.backtrace
      else
        show_timeline(@current_timeline_type, @current_timeline)
      end
    end

    def show_conversation_timeline(id)
      @current_timeline_type = "conversation" 
      begin
        @view.statusbar_refresh('Loading conversation... ')
        @current_timeline = @model.client.conversation_timeline(id)
      rescue Timeout::Error, StandardError=> e
        @view.statusbar_refresh('Error(' + @current_timeline_type + '):' + e.to_s)
        puts 'Error : (' + @current_timeline_type + ')'
        puts e.to_s
        puts e.backtrace
      else
        show_timeline(@current_timeline_type, @current_timeline, false)
      end
    end

    def show_timeline(type, timeline, pageable=true)
      @view.show_timeline(@parser.set_tl(timeline, pageable))
      @view.statusbar_refresh('Show: ' + type)
    end

    def linked_request(entry)
=begin
# debug message
puts "location: " + entry.location.to_s     + " via: " + @view.timeline.location.to_s
puts "js_status:" + entry.js_status.to_s    + " via: " + @view.timeline.js_status.to_s
puts "link_msg: " + entry.link_message.to_s + " via: " + @view.timeline.link_message.to_s
puts "patetitle:" + entry.title.to_s +        " via: " + @view.timeline.title.to_s
=end
      if entry.title.to_s.index('RiTsutter:') == 0 then
        arg   = entry.title.split(':')
        arg.shift
        code  = arg.shift

        if    code == 'addFavorite' then
          add_fav(arg[0])
        elsif code == 'delFavorite' then
          del_fav(arg[0])
        elsif code == 'quote' then
          quote_status(arg[0])
        elsif code == 'reply' then
          reply_status(arg[0])
        elsif code == 'retweet' then
          retweet_status(arg[0])
        elsif code == 'delete_tweet' then
          destroy_status(arg[0])
        elsif code == 'delete_retweet' then
          destroy_retweet_status(arg[0])
        elsif code == 'search' then
          show_search_timeline(arg[0])
        elsif code == 'conversation' then
          show_conversation_timeline(arg[0].to_i)
        elsif code == 'new_timeline' then
          add_new_timeline
        elsif code == 'old_timeline' then
          add_old_timeline
        else
          @view.statusbar_refresh('Undefined Command: ' + entry.link_message.to_s)
        end
      elsif entry.link_message.to_s.index('http') == 0 then
        if @last_message != entry.link_message.to_s then
          @view.timeline.load_url(entry.link_message)
        end
        @last_message = entry.link_message
      end
    end

    def add_fav(id)
      @model.client.favorite_create(id)
      @current_timeline.each{|tweet|
        if tweet.id.to_s == id
          @current_timeline[@current_timeline.index(tweet)] = @model.client.status(id)
        end
      }
      show_timeline(@current_timeline_type, @current_timeline)
      @view.statusbar_refresh('Add Favorite:' + id)
    end

    def del_fav(id)
      @model.client.favorite_destroy(id)
      @current_timeline.each{|tweet|
        if tweet.id.to_s == id
          @current_timeline[@current_timeline.index(tweet)] = @model.client.status(id)
        end
      }
      show_timeline(@current_timeline_type, @current_timeline)
      @view.statusbar_refresh('Delete Favorite:' + id)
    end

    def quote_status(id)
      target = @model.client.status(id.to_i)
      @view.tweet_change(' QT @' + target.user.screen_name + ' https://twitter.com/' + target.user.screen_name + '/status/' + id)
      @view.statusbar_refresh('QT @' + target.user.screen_name + '(' + id + ')')
    end

    def reply_status(id)
      target = @model.client.status(id.to_i)
      @view.tweet_change('@' + target.user.screen_name + ' ' + @view.tweet_box.text)
      @tweet_option.store("in_reply_to_status_id", id)
      @view.statusbar_refresh('in_reply_to:' + target.user.screen_name + '(' + id.to_s + ')')
    end

    def retweet_status(id)
      message_box = Gtk::MessageDialog.new(nil,
                                           Gtk::MessageDialog::MODAL,
                                           Gtk::MessageDialog::QUESTION,
                                           Gtk::MessageDialog::BUTTONS_OK_CANCEL,
                                           'Retweet this message?')
      message_box.run{ |response|
        if response == Gtk::Dialog::RESPONSE_OK then
          @model.client.retweet(id.to_i)
          after_post_cleanup
        end
       }
      message_box.close
      @view.statusbar_refresh('Retweeted:' + id.to_s)
    end

    def destroy_status(id)
      message_box = Gtk::MessageDialog.new(nil,
                                           Gtk::MessageDialog::MODAL,
                                           Gtk::MessageDialog::QUESTION,
                                           Gtk::MessageDialog::BUTTONS_OK_CANCEL,
                                           'Delete this message?')
      message_box.run{ |response|
        if response == Gtk::Dialog::RESPONSE_OK then
          @model.client.status_destroy(id.to_i)
          after_post_cleanup
        end
       }
      message_box.close
      @view.statusbar_refresh('Retweeted:' + id.to_s)
    end

    def tweet_status()
      if @view.tweet_box.text == "" then
        refresh_timeline
        return
      elsif @view.tweet_box.text[0,1] == '@' then
        @model.tweet(@view.tweet_box.text, @tweet_option) # regard tweet option "in_reply_to_status"
      else
        @model.tweet(@view.tweet_box.text)
      end
      after_post_cleanup
    end

    def after_post_cleanup()
      @tweet_option.clear
      @view.tweet_change("")
      @parser.update_id(@model.my_id)
      refresh_timeline("show")
    end
  end

end
