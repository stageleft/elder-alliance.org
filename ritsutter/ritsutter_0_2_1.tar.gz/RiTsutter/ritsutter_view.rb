require 'gtk2'
require 'gtkmozembed'

module RiTsutter
  class View

    attr_reader :main_window, :window_layout
    attr_reader :menu_setting
    attr_reader :timeline, :tweet_button
    attr_reader :home_tl_button, :replytl_button, :self_tl_button
    attr_accessor :tweet_box

    def initialize()
      @main_window       = Gtk::Window.new()
      @main_window.title = $APPNAME

      @main_window.resizable      = true
      @main_window.default_width  = $WIDTH
      @main_window.default_height = $HEIGHT

      @menu         = Gtk::MenuBar.new()
      @menu_setting = Gtk::MenuItem.new("_Setting", true)     # :label => "&Setting", :use_underline => true)
      @menu_version = Gtk::MenuItem.new("_About", true)       # :label => "&About RiTsutter", :use_underline => true
      @menu.append(@menu_setting)
      @menu.append(@menu_version)

      @tweet_box    = Gtk::Entry.new()
      @tweet_box.max_length = 140
      @tweet_button = Gtk::Button.new("_Tweet/Refresh", true) #:text => "&Tweet/Refresh", :use_underline => true
      tweet_layout = Gtk::HBox.new()
      tweet_layout.pack_start(@tweet_box, true, true)
      tweet_layout.pack_start(@tweet_button, false, false)

      @timeline     = Gtk::MozEmbed.new()

      @home_tl_button = Gtk::Button.new("_Home", true)        # :text => "&Home", :use_underline => true
      @replytl_button = Gtk::Button.new("_Mention", true)     # :text => "&Mention", :use_underline => true
      @self_tl_button = Gtk::Button.new("_Self", true)        # :text => "&Self", :use_underline => true
      tl_layout = Gtk::HBox.new()
      tl_layout.pack_start(@home_tl_button, true, true)
      tl_layout.pack_start(@replytl_button, true, true)
      tl_layout.pack_start(@self_tl_button, true, true)

      @status_bar     = Gtk::Statusbar.new()
      @statusbar_id   = @status_bar.get_context_id("RiTsutter")
      @status_bar.push(@statusbar_id, "RiTsutter Running...")

      window_layout = Gtk::VBox.new()
      window_layout.pack_start(@menu, false, false)
      window_layout.pack_start(tweet_layout, false, false)
      window_layout.pack_start(@timeline, true, true)
      window_layout.pack_start(tl_layout, false, false)
      window_layout.pack_start(@status_bar, false, false)

      @main_window.add(window_layout)
      @main_window.show_all
    end

    def run
      @menu_version.signal_connect("select") { about_ritsutter }
      @main_window.signal_connect("destroy") { Gtk.main_quit }
      Gtk.main
    end

    def show_timeline(html_text)
      @timeline.open_stream("file://" + File.expand_path(__FILE__), "text/html")
      @timeline.append_data(html_text)
      @timeline.close_stream()
    end

    def statusbar_refresh(text)
      @status_bar.pop(@statusbar_id)
      @status_bar.push(@statusbar_id, text)
    end

    def about_ritsutter()
      Gtk::AboutDialog.show(nil,
                            :name         => $APPNAME,
                            :version      => $APPVER,
                            :copyright    => $COPYRIGHT,
                            :comments     => $ABOUT_COMMENT,
                            :license      => $LICENSE,
                            :website      => $WEB_SITE,
                            :logo         => Gdk::Pixbuf.new($ICON),
                            :program_name => $APPNAME)
    end
  end
end

