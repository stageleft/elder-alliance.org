require 'parsedate'

module RiTsutter
  class Parser
    def initialize(id="")
      update_id(id)
    end

    def update_id(id)
      @my_id = id
    end

    def set_tl(tl, pageable)
      txt = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">'
      txt = txt + '<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ja" lang="ja">' 
      txt = txt + '<head>'
      txt = txt + '<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />'
      txt = txt + '<meta content="en-us" http-equiv="Content-Language" />'
      txt = txt + '<script type="text/javascript">function addFavorite(id){document.title="RiTsutter:addFavorite:"+id}</script>'
      txt = txt + '<script type="text/javascript">function delFavorite(id){document.title="RiTsutter:delFavorite:"+id}</script>'
      txt = txt + '<script type="text/javascript">function quote(id){document.title="RiTsutter:quote:"+id}</script>'
      txt = txt + '<script type="text/javascript">function retweet(id){document.title="RiTsutter:retweet:"+id}</script>'
      txt = txt + '<script type="text/javascript">function reply(id){document.title="RiTsutter:reply:"+id}</script>'
      txt = txt + '<script type="text/javascript">function delete_tweet(id){document.title="RiTsutter:delete_tweet:"+id}</script>'
      txt = txt + '<script type="text/javascript">function delete_retweet(id){document.title="RiTsutter:delete_retweet:"+id}</script>'
      txt = txt + '<script type="text/javascript">function conversation(id){document.title="RiTsutter:conversation:"+id}</script>'
      txt = txt + '<script type="text/javascript">function new_timeline(id){document.title="RiTsutter:new_timeline:"+id}</script>'
      txt = txt + '<script type="text/javascript">function old_timeline(id){document.title="RiTsutter:old_timeline:"+id}</script>'
      txt = txt + '</head>'
      txt = txt + '<body><hr>'
      if pageable == true then
        txt = txt + '<a href="javascript:new_timeline(' + tl.first.id.to_s + ')">'
        txt = txt + '<table width="100%" style="table-layout: fixed; color: #888888;"><tr>'
        txt = txt + '<td style="text-align: center;">'
        txt = txt + '新しいツイート'
        txt = txt + '</td>'
        txt = txt + '</tr></table>'
        txt = txt + '</a>'
      end
      tl.each{ |tweet|
        txt = txt + set_tw(tweet) + '<hr>'
      }
      if pageable == true then
        txt = txt + '<a href="javascript:old_timeline(0)">'
        txt = txt + '<table width="100%" style="table-layout: fixed; color: #888888;"><tr>'
        txt = txt + '<td style="text-align: center;">'
        txt = txt + '古いツイート'
        txt = txt + '</td>'
        txt = txt + '</tr></table>'
        txt = txt + '</a>'
      end
      txt = txt + '</body></html>'
      return txt
    end

    def set_tw(tweet)
      if tweet.retweeted_status == nil then
        return tw_tweet(tweet)
      else
        return tw_retweet(tweet)
      end
    end

    def tw_tweet(tweet)
      txt = '<table border="1" width="100%" style="table-layout: fixed;">'
      txt = txt + '<tr>' + '<td width="48">'
      txt = txt + tw_fav_icon(tweet) + '<br />'
      txt = txt + '<img src="' + tweet.user.profile_image_url + '" width="48" height="48">'
      txt = txt + '</td><td>'
      txt = txt + tw_username(tweet) + '<br />'
      txt = txt + add_link_tag(tweet.text)
      txt = txt + '</td></tr>'
      txt = txt + '<tr><td colspan="2">'
      txt = txt + tw_time(tweet)
      txt = txt + ' by ' + tweet.source + '<br />'
      txt = txt + tw_quote_icon(tweet)
      txt = txt + tw_reply_icon(tweet)
      txt = txt + tw_retweet_icon(tweet)
      txt = txt + tw_delete_icon(tweet)
      txt = txt + tw_conversation_icon(tweet)
      txt = txt + '</td></tr></table>'
      return txt
    end

    def tw_retweet(tweet)
      txt = '<table border="1" width="100%" style="table-layout: fixed;">'
      txt = txt + '<tr>' + '<td width="48">'
      txt = txt + tw_fav_icon(tweet) + '<br />'
      txt = txt + '<img src="' + tweet.retweeted_status.user.profile_image_url + '" width="48" height="48"><br />'
      txt = txt + '<img src="retweet.png" width="16" height="16">'
      txt = txt + '<img src="' + tweet.user.profile_image_url + '" width="24" height="24">'
      txt = txt + '</td><td>'
      txt = txt + tw_username(tweet.retweeted_status) + '<br />'
      txt = txt + ' RT by ' + tw_username(tweet) + '<br />'
      txt = txt + add_link_tag(tweet.retweeted_status.text)
      txt = txt + '</td></tr>'
      txt = txt + '<tr><td colspan="2">'
      txt = txt + tw_time(tweet.retweeted_status)
      txt = txt + ' by ' + tweet.retweeted_status.source + '<br />'
      txt = txt + 'RT:' + tw_time(tweet)
      txt = txt + ' by ' + tweet.source + '<br />'
      txt = txt + tw_quote_icon(tweet.retweeted_status)
      txt = txt + tw_reply_icon(tweet.retweeted_status)
      txt = txt + tw_retweet_icon(tweet.retweeted_status)
      txt = txt + tw_conversation_icon(tweet.retweeted_status)
      txt = txt + '</td></tr></table>'
      return txt
    end

    def tw_username(tweet)
      txt = '<a href="https://twitter.com/' + tweet.user.screen_name + '">'
      txt = txt + tweet.user.screen_name
      txt = txt + '</a>'
      txt = txt + '(' + tweet.user.name + ')'
      return txt
    end

    def tw_fav_icon(tweet)
      h_txt = '<a href="javascript:'
      m_txt = '(' + tweet.id.to_s + ')"><img src='
      l_txt = ' width="16" height="16"></a>'
      if tweet.favorited == false then
        txt = h_txt + 'addFavorite' + m_txt + '"non_favo.png"' + l_txt
      else
        txt = h_txt + 'delFavorite' + m_txt + '"favorite.png"' + l_txt
      end
      return txt
    end

    def tw_time(tweet)  # Timezone:Ruby実行環境と思われる(作者環境ではTokyo)
      time = Time.parse(tweet.created_at)
      txt = time.strftime("%Y-%m-%d %H:%M:%S")
      return txt
    end

    def tw_quote_icon(tweet)
      if tweet.user.protected == true then
        txt = ""
      else
        txt = '<a href="javascript:quote(' + tweet.id.to_s + ')">'
        txt = txt + '<img src="quote.png" width="16" height="16">'
        txt = txt + 'Quote</a> '
      end
      return txt
    end

    def tw_retweet_icon(tweet)
      if tweet.user.protected == true || tweet.user.id == @my_id then
        txt = ""
      else
        txt = '<a href="javascript:retweet(' + tweet.id.to_s + ')">'
        txt = txt + '<img src="retweet.png" width="16" height="16">'
        txt = txt + 'Retweet</a> '
      end
      return txt
    end

    def tw_reply_icon(tweet)
      txt = '<a href="javascript:reply(' + tweet.id.to_s + ')">'
      txt = txt + '<img src="reply.png" width="16" height="16">'
      txt = txt + 'Reply</a> '
      return txt
    end

    def tw_conversation_icon(tweet)
      if tweet.in_reply_to_status_id == nil then
        txt = ""
      else
        txt = '<a href="javascript:conversation(' + tweet.id.to_s + ')">'
        txt = txt + '<img src="conversation.png" width="16" height="16">'
        txt = txt + 'Conversation</a> '
      end
      return txt
    end

    def tw_delete_icon(tweet)
      if tweet.user.id != @my_id then
        txt = ""
      else
        txt = '<a href="javascript:delete_tweet(' + tweet.id.to_s + ')">'
        txt = txt + '<img src="del_tweet.png" width="16" height="16">'
        txt = txt + 'Delete</a> '
      end
      return txt
    end

    def tw_delete_retweet_icon(tweet)
      if tweet.user.id != @my_id then
        txt = ""
      else
        txt = '<a href="javascript:delete_retweet(' + tweet.id.to_s + ')">'
        txt = txt + '<img src="del_tweet.png" width="16" height="16">'
        txt = txt + 'Delete your retweet</a> '
      end
      return txt
    end

    def add_link_tag(text)
      return add_hash(add_id(add_https(add_http(text))))
    end

    def add_http(text)
      text_array = text.split('http://')
      ret_text = text_array.shift
      text_array.each{ |t|
        urlstr = t.split(/[^\!-\~]/)[0]
        if urlstr == nil then
          ret_text = ret_text + 'http://' + t
        else
          nourlstr = t[(urlstr.size)..(t.size)]
          ret_text = ret_text + '<a href="http://' + urlstr + '">' + 'http://' + urlstr + '</a>' + nourlstr
        end
      }
      return ret_text
    end

    def add_https(text)
      text_array = text.split('https://')
      ret_text = text_array.shift
      text_array.each{ |t|
        urlstr = t.split(/[^\!-\~]/)[0]
        if urlstr == nil then
          ret_text = ret_text + 'https://' + t
        else
          nourlstr = t[(urlstr.size)..(t.size)]
          ret_text = ret_text + '<a href="https://' + urlstr + '">' + 'https://' + urlstr + '</a>' + nourlstr
        end
      }
      return ret_text
    end

    def add_id(text)
      text_array = text.split('@')
      ret_text = text_array.shift
      text_array.each{ |t|
        urlstr = t.split(/[^0-9A-Za-z_]/)[0]
        if urlstr == nil then
          ret_text = ret_text + '@' + t
        else
          nourlstr = t[(urlstr.size)..(t.size)]
          ret_text = ret_text + '@<a href="https://twitter.com/' + urlstr + '/">' + urlstr + '</a>' + nourlstr
        end
      }
      return ret_text
    end

    def add_hash(text)
      text_array = text.split('#')
      ret_text = text_array.shift
      text_array.each{ |t|
        urlstr = t.split(/\s/)[0]
        if urlstr == nil then
          ret_text = ret_text + '#' + t
        else
          nourlstr = t[(urlstr.size)..(t.size)]
          ret_text = ret_text + '#<a href="http://twitter.com/#search?q=%23' + urlstr + '/">' + urlstr + '</a>' + nourlstr
        end
      }
      return ret_text
    end

  end
end
