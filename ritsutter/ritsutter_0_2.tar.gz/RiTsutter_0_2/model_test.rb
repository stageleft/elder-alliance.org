#!/usr/bin/ruby

require 'ritsutter_model.rb'
open('RiTsutter_Access.txt'){ |file|
  $CONSUMER_KEY    = file.gets.delete(" \t\n\r\f")
  $CONSUMER_SECRET = file.gets.delete(" \t\n\r\f")
  $ACCESS_TOKEN    = file.gets.delete(" \t\n\r\f")
  $ACCESS_SECRET   = file.gets.delete(" \t\n\r\f")
}

tw = RiTsutter::Model.new()
tw.client.home_timeline.each { |tweet|
  puts "(" + tweet.id.to_s + ")" + tweet.user.screen_name + ": " + tweet.text
  puts tweet.inspect
}
puts
tw.client.user_timeline.each { |tweet|
  puts "(" + tweet.id.to_s + ")" + tweet.user.screen_name + ": " + tweet.text
  puts tweet.inspect
}
puts
tw.client.mentions.each { |tweet|
  puts "(" + tweet.id.to_s + ")" + tweet.user.screen_name + ": " + tweet.text
  puts tweet.inspect
}
puts
