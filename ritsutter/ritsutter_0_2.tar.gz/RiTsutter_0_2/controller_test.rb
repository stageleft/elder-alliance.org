#!/usr/bin/ruby

require 'ritsutter_controller.rb'
require 'ritsutter_model.rb'

ct = RiTsutter::Controller.new()
mo = RiTsutter::Model.new()

html = ct.make_timeline(mo.client.home_timeline)
puts html
