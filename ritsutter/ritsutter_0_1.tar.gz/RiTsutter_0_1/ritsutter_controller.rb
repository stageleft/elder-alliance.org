require 'ritsutter_model.rb'
require 'ritsutter_view.rb'

module RiTsutter
  class Controller

    def initialize()
      @view  = RiTsutter::View.new()
      @model = RiTsutter::Model.new()

      @lase_message = ""
      @tweet_option = Hash.new()

      @view.home_tl_button.signal_connect("clicked") { show_home_timeline }
      @view.replytl_button.signal_connect("clicked"){ show_reply_timeline }
      @view.self_tl_button.signal_connect("clicked") { show_self_timeline }
      @view.timeline.signal_connect("js_status")  { |widget| linked_request(widget) }
      @view.tweet_button.signal_connect("clicked")    { tweet_status }

      @view.main_window.show_all
      show_home_timeline

      @view.run
    end

    def add_link_tag(text)
      return add_link_tag_id(add_link_tag_https(add_link_tag_http(text)))
    end

    def add_link_tag_http(text)
      text_array = text.split('http://')
      ret_text = text_array.shift
      text_array.each{ |t|
        urlstr = t.split(/[^\!-\~]/)[0]
        nourlstr = t[(urlstr.size)..(t.size)]
        ret_text = ret_text + '<a href="http://' + urlstr + '">' + 'http://' + urlstr + '</a>' + nourlstr
      }
      return ret_text
    end

    def add_link_tag_https(text)
      text_array = text.split('https://')
      ret_text = text_array.shift
      text_array.each{ |t|
        urlstr = t.split(/[^\!-\~]/)[0]
        nourlstr = t[(urlstr.size)..(t.size)]
        ret_text = ret_text + '<a href="https://' + urlstr + '">' + 'https://' + urlstr + '</a>' + nourlstr
      }
      return ret_text
    end

    def add_link_tag_id(text)
      text_array = text.split('@')
      ret_text = text_array.shift
      text_array.each{ |t|
        urlstr = t.split(/[^0-9A-Za-z_]/)[0]
        nourlstr = t[(urlstr.size)..(t.size)]
        ret_text = ret_text + '@<a href="https://twitter.com/' + urlstr + '/">' + urlstr + '</a>' + nourlstr
      }
      return ret_text
    end

    def make_html(tweet)
      html_string = '<table border="1" width="100%" style="table-layout: fixed;">'
      html_string = html_string + '<tr>'
      html_string = html_string + '<td width="48">'
      html_string = html_string + '<img src="' + tweet.user.profile_image_url + '" width="48" height="48">'
      html_string = html_string + '</td>'
      html_string = html_string + '<td>'
      html_string = html_string + tweet.user.screen_name + '(' + tweet.user.name + ')<br />'
      html_string = html_string + add_link_tag(tweet.text)
      html_string = html_string + '</td>'
      html_string = html_string + '</tr>'
      html_string = html_string + '<tr>'
      html_string = html_string + '<td colspan="2">'
      if tweet.favorited == false then
        html_string = html_string + '<a href="javascript:addFavorite(' + tweet.id.to_s + ')" alt="Add to Favorite"     ><img src="non_favo.png" width="16" height="16"></a>'
      else
        html_string = html_string + '<a href="javascript:delFavorite(' + tweet.id.to_s + ')" alt="Delete from Favorite"><img src="favorite.png" width="16" height="16"></a>'
      end
      html_string = html_string + '　'
      html_string = html_string + tweet.created_at
      html_string = html_string + '　'
      html_string = html_string + 'posted by ' + tweet.source
      html_string = html_string + '　'
      html_string = html_string + '<a href="javascript:quote(' + tweet.id.to_s + ')" alt="Quote(RiTsutter)"><img src="quote.png" width="16" height="16"></a>'
      html_string = html_string + '　'
      html_string = html_string + '<a href="javascript:retweet(' + tweet.id.to_s + ')" alt="Retweet"><img src="retweet.png" width="16" height="16"></a>'
      html_string = html_string + '　'
      html_string = html_string + '<a href="javascript:reply(' + tweet.id.to_s + ')" alt="Reply"><img src="reply.png" width="16" height="16"></a>'
      html_string = html_string + '　'
      html_string = html_string + '<a href="javascript:conversation(' + tweet.id.to_s + ')" alt="Show Conversation"><img src="conversation.png"  width="16" height="16"></a>'
      html_string = html_string + '</td>'
      html_string = html_string + '</tr>'
      html_string = html_string + '</table>'
      return html_string
    end

    def make_timeline(tl)
      html_text = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">'
      html_text = html_text + '<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ja" lang="ja">' 
      html_text = html_text + '<head>'
      html_text = html_text + '<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />'
      html_text = html_text + '<meta content="en-us" http-equiv="Content-Language" />'
      html_text = html_text + '<script type="text/javascript">function addFavorite(id){window.status=id}</script>'
      html_text = html_text + '<script type="text/javascript">function delFavorite(id){window.status=id}</script>'
      html_text = html_text + '<script type="text/javascript">function quote(id){window.status=id}</script>'
      html_text = html_text + '<script type="text/javascript">function retweet(id){window.status=id}</script>'
      html_text = html_text + '<script type="text/javascript">function reply(id){window.status=id}</script>'
      html_text = html_text + '<script type="text/javascript">function conversation(id){window.status=id}</script>'
      html_text = html_text + '</head>'
      html_text = html_text + '<body><hr>'
      tl.each{ |tweet|
        html_text = html_text + make_html(tweet) + '<hr>'
      }
      html_text = html_text + '</body></html>'
      return html_text
    end

    def show_home_timeline()
      begin
        tl = make_timeline(@model.client.home_timeline())
      rescue => e
        @view.statusbar_refresh('home_tl:' + e.to_s)
      else
        @view.show_timeline(tl)
      end
    end

    def show_reply_timeline()
      begin
        tl = make_timeline(@model.client.mentions())
      rescue => e
        @view.statusbar_refresh('reply_tl:' + e.to_s)
      else
        @view.show_timeline(tl)
      end
    end

    def show_self_timeline()
      begin
        tl = make_timeline(@model.client.user_timeline())
      rescue => e
        @view.statusbar_refresh('self_tl:' + e.to_s)
      else
        @view.show_timeline(tl)
      end
    end

    def show_conversation_timeline(id)
      begin
        tl = make_timeline(@model.client.conversation_timeline(id))
      rescue => e
        @view.statusbar_refresh(e.to_s)
      else
        @view.show_timeline(tl)
      end
    end

    def linked_request(entry)
=begin
# debug message
puts "location: " + entry.location.to_s     + " via: " + @view.timeline.location.to_s
puts "js_status:" + entry.js_status.to_s    + " via: " + @view.timeline.js_status.to_s
puts "link_msg: " + entry.link_message.to_s + " via: " + @view.timeline.link_message.to_s
=end
      # 同一コマンド多重実行の抑止
      if @last_message == entry.link_message.to_s then
        @last_message = entry.link_message.to_s
        return
      end
      @last_message = entry.link_message.to_s

      if entry.link_message.to_s.index('javascript') == 0 then
        arg   = entry.link_message.split(':')[1].split(/\(|,|\)/).flatten
        code  = arg.shift

        if    code == 'addFavorite' then
          @model.client.favorite_create(arg[0])
          @view.statusbar_refresh('Add Favorite:' + arg[0])
        elsif code == 'delFavorite' then
          @model.client.favorite_destroy(arg[0])
          @view.statusbar_refresh('Delete Favorite:' + arg[0])
        elsif code == 'quote' then
          quote_status(arg[0])
        elsif code == 'reply' then
          reply_status(arg[0])
        elsif code == 'retweet' then
          retweet_status(arg[0])
        elsif code == 'conversation' then
          show_conversation_timeline(arg[0].to_i)
        end
      elsif entry.link_message.to_s.index('http') == 0 then
        @view.timeline.load_url(entry.link_message)
      end
    end

    def quote_status(id)
      target = @model.client.status(id.to_i)
      @view.tweet_box.text = ' QT @' + target.user.screen_name + ' https://twitter.com/' + target.user.screen_name + '/status/' + id
      show_conversation_timeline(id.to_i)
      @view.statusbar_refresh('QT @' + target.user.screen_name + '(' + id + ')')
    end

    def reply_status(id)
      target = @model.client.status(id.to_i)
      @view.tweet_box.text = '@' + target.user.screen_name + ' '
      @tweet_option.store("in_reply_to_status_id", id)
      show_conversation_timeline(id.to_i)
      @view.statusbar_refresh('in_reply_to:' + target.user.screen_name + '(' + id.to_s + ')')
    end

    def retweet_status(id)
      message_box = Gtk::MessageDialog.new(nil,
                                           Gtk::MessageDialog::MODAL,
                                           Gtk::MessageDialog::QUESTION,
                                           Gtk::MessageDialog::BUTTONS_OK_CANCEL,
                                           'Retweet this message?')
      message_box.run{ |response|
        if response == Gtk::Dialog::RESPONSE_OK then
          @model.client.retweet(id.to_i)
          after_post_cleanup
        else
        end
       }
      message_box.close
      @view.statusbar_refresh('Retweeted:' + id.to_s)
    end

    def tweet_status()
      if @view.tweet_box.text[0,1] == '@' then
        @model.client.update(@view.tweet_box.text, @tweet_option) # regard tweet option "in_reply_to_status"
      else
        @model.client.update(@view.tweet_box.text)
      end
      after_post_cleanup
    end

    def after_post_cleanup()
      @tweet_option.clear
      @view.tweet_box.text = ""
      show_home_timeline
    end
  end

end
