#!/usr/bin/ruby

# constants

# for RiTsutter::View
$APPNAME = 'Ritsutter'
$ICON    = 'ritsutter_icon.png'
$WIDTH   = 400
$HEIGHT  = 720
$X_POS   = 0
$Y_POS   = 0

require 'gtk2'
require 'ritsutter_view.rb'

test_view = RiTsutter::View.new()
#test_view.add(test_view.window_layout)
#test_view.signal_connect("destroy") {
#  Gtk.main_quit
#}

test_view.run

