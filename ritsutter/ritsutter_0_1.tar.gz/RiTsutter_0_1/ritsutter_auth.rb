#!/usr/bin/ruby

require 'rubygems'
require 'oauth'
require 'gtk2'
require 'gtkmozembed'

$TITLE = 'RiTsutter authenticator by OAuth'

$ACCESS_KEY_FILE         = 'RiTsutter_Access.txt'
$DEFAULT_CONSUMER_KEY    = 'gAIRqtdHVXtuBdLw3FzFEA'
$DEFAULT_CONSUMER_SECRET = 'qsdkxf1FGZ1LvjbBTVWqxhzgkUnKiklhdX4bHCq7iV8'

class Twitter_OAuth
  def initialize()
    @consumer_key    = ""
    @consumer_secret = ""
    @last_message    = ""
    @request_token   = nil

    @auth_window       = Gtk::Window.new()
    @auth_window.title = $TITLE
    @auth_window.default_width  = 800
    @auth_window.default_height = 600
    @auth_window.resizable      = true

    @auth_view         = Gtk::MozEmbed.new()

    @auth_pin          = Gtk::HBox.new()
    @auth_pin_label    = Gtk::Label.new('your PIN code :', false)
    @auth_pin.pack_start(@auth_pin_label, false, false)
    @auth_pin_entry    = Gtk::Entry.new()
    @auth_pin.pack_start(@auth_pin_entry, true, true)
    @auth_pin_submit   = Gtk::Button.new('Send')
    @auth_pin.pack_start(@auth_pin_submit, false, false)

    @auth_statusbar    = Gtk::Statusbar.new()

    @auth_layout       = Gtk::VBox.new()
    @auth_layout.pack_start(@auth_view,      true,  true)
    @auth_layout.pack_start(@auth_pin,       false, false)
    @auth_layout.pack_start(@auth_statusbar, false, false)
    @auth_window.add(@auth_layout)

    @auth_view.signal_connect("title") { |widget| page_title_changed(widget) }
    @auth_pin_submit.signal_connect("clicked") { send_auth_key }
    @auth_window.signal_connect("destroy") { Gtk.main_quit }

    @auth_window.show_all
    auth_init()
  end

  def show_html(print_title, print_text)
    html_text = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">'
    html_text = html_text + '<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ja" lang="ja">' 
    html_text = html_text + '<head>'
    html_text = html_text + '<title>' + print_title + '</title>'
    html_text = html_text + '<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />'
    html_text = html_text + '<meta content="en-us" http-equiv="Content-Language" />'
    html_text = html_text + '<script type="text/javascript">function init_send(){'
    html_text = html_text + '  document.title = ("RiTsutter_i2a " + document.init_key.c_key.value + " " + document.init_key.c_secret.value);'
    html_text = html_text + '}</script>'
    html_text = html_text + '<script type="text/javascript">function init_reset(){'
    html_text = html_text + '  document.init_key.c_key.value    = "' + $DEFAULT_CONSUMER_KEY    + '";'
    html_text = html_text + '  document.init_key.c_secret.value = "' + $DEFAULT_CONSUMER_SECRET + '";'
    html_text = html_text + '}</script>'
    html_text = html_text + '</head>'
    html_text = html_text + '<body>'
    html_text = html_text + print_text
    html_text = html_text + '</body></html>'

    @auth_view.open_stream("file://" + File.expand_path(__FILE__), "text/html")
    @auth_view.append_data(html_text)
    @auth_view.close_stream()
  end

  def auth_init()
    # Step 0/7: developper gets CONSUMER_KEY and CONSUMER_SECRET from twitter.com
    init_html = '<h1>' + $TITLE + '</h1>'
    init_html = init_html + '<p>input CONSUMER_KEY and CONSUMER_SECRET of your RiTsutter</p>'
    init_html = init_html + '<form name="init_key">'
    init_html = init_html + 'Consumer Key:<br />'
    init_html = init_html + '<input type="text" name="c_key" value="' + $DEFAULT_CONSUMER_KEY + '" size="60">'
    init_html = init_html + '<br />'
    init_html = init_html + 'Consumer Secret:<br />'
    init_html = init_html + '<input type="text" name="c_secret" value="' + $DEFAULT_CONSUMER_SECRET + '" size="60">'
    init_html = init_html + '</form>'
    init_html = init_html + '<p>'
    init_html = init_html + '<a href="javascript:init_send()">Autenticate with this ConsumerKey/ConsumerSecret</a>'
    init_html = init_html + '</p><p>'
    init_html = init_html + '<a href="javascript:init_reset()">Set default ConsumerKey/ConsumerSecret</a>'
    init_html = init_html + '</p>'

    show_html('RiTsutter_init', init_html)
  end

  def auth_start(key, secret)
    @consumer_key    = key
    @consumer_secret = secret

    if @consumer_key    == "" or @consumer_key    == nil then
      return
    end
    if @consumer_secret == "" or @consumer_secret == nil then
      return
    end

    # step 1/7: user commands RiTsutter to OAuth
    consumer = OAuth::Consumer.new(
                                   @consumer_key,
                                   @consumer_secret,
                                   {:site => 'http://twitter.com/'}
                                  )

    # step 2/7: RiTsutter gets REQUEST_TOKEN from twitter.com
    auth_html = '<h1>' + $TITLE + '</h1>'
    auth_html = auth_html + '<p>getting Request Token ...</p>'
    show_html('RiTsutter_wait', auth_html)

    begin
      @request_token = consumer.get_request_token
    rescue => e
      msg = Gtk::MessageDialog.new(nil,
                                   Gtk::MessageDialog::MODAL,
                                   Gtk::MessageDialog::WARNING,
                                   Gtk::MessageDialog::BUTTONS_CLOSE,
                                  'Fatal Error: Request Token Failed.' + "\n" + e.to_s)
      msg.run{|ret|}
      Gtk.main_quit
    else
      if @request_token == nil then
        puts "illegal token"
        retry
      end
    end

    # step 3/7: user gets VERIFIER (autholize REQUEST_TOKEN) in twitter.com
    auth_html = '<h1>' + $TITLE + '</h1>'
    auth_html = auth_html + '<p>'
    auth_html = auth_html + '<p>check CONSUMER_KEY and CONSUMER_SECRET of your RiTsutter</p>'
    auth_html = auth_html + 'Your Consumer Key   : ' + @consumer_key
    auth_html = auth_html + '</p>'
    auth_html = auth_html + '<p>'
    auth_html = auth_html + 'Your Consumer Secret: ' + @consumer_secret
    auth_html = auth_html + '</p>'
    auth_html = auth_html + '<p>'
    auth_html = auth_html + '<a href="' + @request_token.authorize_url + '">Click to authorize your Consumer Key/Secret</a>'
    auth_html = auth_html + '</p>'

    show_html('RiTsutter_auth', auth_html)
  end

  def send_auth_key()
    if @request_token == nil then
      return
    end
    if @auth_pin_entry.text.to_s == "" then
      return
    end

    # step 4/7: user sets VERIFIER to RiTsutter
    oauth_verifier = @auth_pin_entry.text.delete("\s")

    # step 5/7: RiTsutter gets Access Token from twitter.com
    begin
      @access_token =  @request_token.get_access_token({:oauth_verifier => oauth_verifier})
    rescue => e
      msg = Gtk::MessageDialog.new(nil,
                                   Gtk::MessageDialog::MODAL,
                                   Gtk::MessageDialog::WARNING,
                                   Gtk::MessageDialog::BUTTONS_CLOSE,
                                   'Fatal Error: Access Token Failed.' + "\n" + e.to_s)
      msg.run{|ret|}
      Gtk.main_quit
    end

    # step 6,7/7: RiTsutter authorizer sets Access Token/Access Token Secret to RiTsutter client
    begin
      out_file = File.open($ACCESS_KEY_FILE, 'w')
      out_file.puts @consumer_key
      out_file.puts @consumer_secret
      out_file.puts @access_token.token
      out_file.puts @access_token.secret
      out_file.puts ""
      out_file.close()
    rescue => e
      msg = Gtk::MessageDialog.new(nil,
                                   Gtk::MessageDialog::MODAL,
                                   Gtk::MessageDialog::WARNING,
                                   Gtk::MessageDialog::BUTTONS_CLOSE,
                                   'Fatal Error: Write File Failed.' + "\n" + e.to_s)
    else
      msg = Gtk::MessageDialog.new(nil,
                                   Gtk::MessageDialog::MODAL,
                                   Gtk::MessageDialog::INFO,
                                   Gtk::MessageDialog::BUTTONS_CLOSE,
                                   'Auth Succeeded.')
      
    ensure
      msg.run{|ret|}
      Gtk.main_quit
    end
  end

  attr_reader :consumer_key
  attr_reader :consumer_secret
  attr_reader :access_token

  def page_title_changed(entry)
#=begin
# debug message
puts "title: " + entry.title.to_s + ' via ' + @auth_view.title
#=end

    if entry.title.to_s.index('RiTsutter') == 0 then
      arg   = entry.title.split(' ')
      code  = arg.shift.sub('RiTsutter_', '')

      if    code == 'i2a'  then # Auth step : 0->1
        auth_start(arg[0], arg[1])
      end
    else
      if @last_message != entry.link_message.to_s then
        @auth_view.load_url(entry.link_message)
      end
      @last_message = entry.link_message
    end
  end
end

begin
  auth_step = Twitter_OAuth.new()
  Gtk.main
rescue => e
  Gtk::MessageDialog.new(nil,
                         Gtk::MessageDialog::MODAL,
                         Gtk::MessageDialog::WARNING,
                         Gtk::MessageDialog::BUTTONS_CLOSE,
                         'Fatal Error' + e.to_s)
else
  Gtk::MessageDialog.new(nil,
                         Gtk::MessageDialog::MODAL,
                         Gtk::MessageDialog::INFO,
                         Gtk::MessageDialog::BUTTONS_CLOSE,
                         'Auth Succeeded.')
end
