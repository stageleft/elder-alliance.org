require 'rubygems'
require 'twitter'

module RiTsutter
  class Base

    attr_reader :status_list

    def initialize(auth)
      @base = Twitter::Base.new(auth)
      @status_list = Array.new()
    end

    # home_timeline with Retweet Chain
    def home_timeline(query={})
      c_list = @base.home_timeline(query)
      c_list.each{ |t|
        t.text = retweet_chain_solver(t)
      }
    end

    # friends_timeline with Retweet Chain
    def friends_timeline(query={})
      c_list = @base.friends_timeline(query)
      c_list.each{ |t|
        t.text = retweet_chain_solver(t)
      }
    end

    # user_timeline with Retweet Chain
    def user_timeline(query={})
      c_list = @base.user_timeline(query)
      c_list.each{ |t|
        t.text = retweet_chain_solver(t)
      }
    end

    def status(id)
      @status_list.each{|id_and_status|
        if id_and_status[0] == id then
          return id_and_status[1]
        end
      }
      result = @base.status(id)
      @status_list.unshift([id, result]) # pushでもよいが、新規登録のサーチ順位を上げるとなんとなく早そうな気がした。
      return result
    end

    # pipe for Twitter::base class
    def retweets(id, query={})
      @base.retweets(id, query)
    end
    def update(id, query={})
      @base.update(id, query)
    end

    # mentions with Retweet Chain
    def mentions(query={})
      c_list = @base.mentions(query)
      c_list.each{ |t|
        t.text = retweet_chain_solver(t)
      }
    end

    # pipe for Twitter::base class
    def retweeted_to_me(query={})
      @base.retweeted_to_me(query)
    end
    def retweets_of_me(query={})
      @base.retweets_of_me(query)
    end
    def retweeters_of(id, query={})
      @base.retweeters_of(id, query)
    end
    def status_destroy(id)
      @base.status_destroy(id)
    end
    def retweet(id)
      @base.retweet(id)
    end
    def favorites(query={})
      @base.favorites(query)
    end
    def favorite_create(id)
      @base.favorite_create(id)
    end
    def favorite_destroy(id)
      @base.favorite_destroy(id)
    end

    # home_timeline with Retweet Chain
    def list_timeline(list_owner_username, query={})
      c_list = @base.list_timeline(list_owner_username, query)
      c_list.each{ |t|
        t.text = retweet_chain_solver(t)
      }
    end

    # Retweet Chain Solver for 1 tweet
    def retweet_chain_solver(status)
      if retweet_status_id(status) != "" then
        return conversation_retweet_chain(Array.new(1){status}).first.text
      else
        return status.text
      end
    end

    # timeline "Conversation"
    def conversation_timeline(id)
      c_list = Array.new(1){ self.status(id) }
      self.conversation_reply_chain(c_list)
      return c_list
    end

    # conversation list with @Reply and repostlinked Retweet
    def conversation_reply_chain(c_list)
      if c_list.last.in_reply_to_status_id != nil then
        c_list.push(self.status(c_list.last.in_reply_to_status_id))
        if c_list.last != nil then
          self.conversation_reply_chain(c_list)
        end
      else
        sub_list = conversation_retweet_chain(Array.new(1){ c_list.last })
        sub_list.each{ |t|
          if t != c_list.last then
            c_list.push(t)
            if t.in_reply_to_status_id != nil
              self.conversation_reply_chain(c_list)
              return c_list
            end
          end
        }
      end
      return c_list
    end

    # conversation list with repostlinked Retweet
    def conversation_retweet_chain(c_list)
      if retweet_status_id(c_list.last) != "" then
        next_tweet = self.status(retweet_status_id(c_list.last))
        if next_tweet != nil then
          c_list.each{ |t|
            if t.text["https://twitter.com/" + next_tweet.user.screen_name + "/status/" + next_tweet.id.to_s] != nil then
              t.text["https://twitter.com/" + next_tweet.user.screen_name + "/status/" + next_tweet.id.to_s] = next_tweet.text
            elsif t.text["http://twitter.com/" + next_tweet.user.screen_name + "/status/" + next_tweet.id.to_s] != nil then
              t.text["http://twitter.com/" + next_tweet.user.screen_name + "/status/" + next_tweet.id.to_s] = next_tweet.text
            end
          }
          c_list.push(next_tweet)
          self.conversation_retweet_chain(c_list)
        end
      end
      return c_list
    end

    def retweet_status_id(status)
      url_list = status.text.split("://twitter.com/")
      url_list.shift
      url_list.each {|s|
        id_list = s.split("/status/")
        id_list.shift
        id_list.each{|id|
          return id[/[0-9]*/]
        }
      }
      return ""
    end
  end

  class Model

    attr_reader :client

    def initialize()
      # Initiate Twitter Client
      auth  = Twitter::OAuth.new($CONSUMER_KEY, $CONSUMER_SECRET)
      auth.authorize_from_access($ACCESS_TOKEN, $ACCESS_SECRET)
      @client = RiTsutter::Base.new(auth)
    end
  end
end

